--- READ ME ---
##################################################################################################
Below are the IMU movement sequences for each data signal. Please note that certain directional keywords (pos/neg, clockwise/counterclockwise) might be "backwards". For example, the signal might actually show a clockwise circle where this READ_ME note indicates a counterclockwise circle occurred. Or this note might say "pos,neg,pos,neg" when in reality the data signal is really "neg,pos,neg,pos". THIS IS NOT A BIG DEAL!!! The only important thing here is the sequence of moves made, not the directions of those moves. It doesn't matter if it's "pos,neg" or "neg,pos", as long as you realize that this means the IMU was tilted one way and then the other way along a given axis. If this paragraph seems confusing to you, just forget about it...I promise it's not important.
##################################################################################################

no_user_input.csv
->> [none, just noise]

slow_user_input.csv
->> neg pitch, pos pitch, neg pitch, pos pitch, neg roll, pos roll, neg roll, pos roll, neg yaw, pos yaw, neg yaw, pos yaw

fast_user_input.csv
->> neg pitch, pos pitch, neg pitch, pos pitch, neg roll, pos roll, neg roll, pos roll, neg yaw, pos yaw, neg yaw, pos yaw 

chaotic-mix_user_input.csv
->> clockwise circle motion, counterclockwise circle motion, random