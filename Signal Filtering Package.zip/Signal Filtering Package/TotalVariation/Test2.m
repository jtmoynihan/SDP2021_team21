y_1 = load('pitch_chaotic_input.txt');

N = length(y_1);
sigma = 0.5;
figure(1)
clf

ax = [0 N 0 180];
plot(y_1)
axis(ax)
title('Pitch output with no filter (chaotic user input)','FontSize', 14)
xlabel('Samples')
ylabel(['Degree (' char(176) ')'])

lam = 10;                         % lam: regularization parameter
Nit = 1000;                          % Nit: number of iterations
[h, cost] = tvd_mm(y_1, lam, Nit);   % Run MM TV denoising algorithm


figure(2)
clf
plot(h)
axis(ax)
title('Pitch output with TV filter(chaotic user input)','FontSize', 14)
ylabel(['Degree (' char(176) ')'])
xlabel('Samples')
