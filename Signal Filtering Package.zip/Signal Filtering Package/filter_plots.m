% Jacob Moynihan
% ECE 416 - Senior Design Project II
% FPR Presentation, Filter Plots

no_user = readmatrix('no_user_input.csv');
slow_user = readmatrix('slow_user_input.csv');
fast_user = readmatrix('fast_user_input.csv');
chaotic_user = readmatrix('chaotic-mix_user_input.csv');

no_pitch = no_user(:,1);
slow_pitch = slow_user(:,1);
fast_pitch = fast_user(:,1);
chaotic_pitch = chaotic_user(:,1);

tn = linspace(1,length(no_pitch),length(no_pitch));
ts = linspace(1,length(slow_pitch),length(slow_pitch));
tf = linspace(1,length(fast_pitch),length(fast_pitch));
tc = linspace(1,length(chaotic_pitch),length(chaotic_pitch));

windowSize = 10;    % window size used in mvgAvg & EWMA filters
a = 0.025;           % value of 'alpha' used in EWMA filter

no_pit_mvgAvg = mvgAvg(no_pitch,windowSize);
slow_pit_mvgAvg = mvgAvg(slow_pitch,windowSize);
fast_pit_mvgAvg = mvgAvg(fast_pitch,windowSize);
chaotic_pit_mvgAvg = mvgAvg(chaotic_pitch,windowSize);

no_pit_EWMA = EWMA(no_pitch,windowSize,a);
slow_pit_EWMA = EWMA(slow_pitch,windowSize,a);
fast_pit_EWMA = EWMA(fast_pitch,windowSize,a);
chaotic_pit_EWMA = EWMA(chaotic_pitch,windowSize,a);

[no_pit_TV,no_pit_cost] = tvd_mm(no_pitch,12.5,100);
[slow_pit_TV,slow_pit_cost] = tvd_mm(slow_pitch,12.5,100);
[fast_pit_TV,fast_pit_cost] = tvd_mm(fast_pitch,12.5,100);
[chaotic_pit_TV,chaotic_pit_cost] = tvd_mm(chaotic_pitch,12.5,100);

no_pit_hybrid = EWMA(no_pit_TV,windowSize,a);
slow_pit_hybrid = EWMA(slow_pit_TV,windowSize,a);
fast_pit_hybrid = EWMA(fast_pit_TV,windowSize,a);
chaotic_pit_hybrid = EWMA(chaotic_pit_TV,windowSize,a);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(1)

subplot(2,2,1)
plot(tn,no_pitch,'k')
title('No Filter (Pitch Signal) - No Hand Movement')
xlabel('Sample #')
ylabel('Degree (�)')
grid on

subplot(2,2,2)
plot(ts,slow_pitch,'k')
title('No Filter (Pitch Signal) - Slow Hand Movement')
xlabel('Sample #')
ylabel('Degree (�)')
grid on

subplot(2,2,3)
plot(tf,fast_pitch,'k')
title('No Filter (Pitch Signal) - Fast Hand Movement')
xlabel('Sample #')
ylabel('Degree (�)')
grid on

subplot(2,2,4)
plot(tc,chaotic_pitch,'k')
title('No Filter (Pitch Signal) - Chaotic Hand Movement')
xlabel('Sample #')
ylabel('Degree (�)')
grid on
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(2)

subplot(2,2,1)
plot(tn,no_pitch,'k')
hold on
plot(tn,no_pit_mvgAvg,'r','LineWidth',0.7)
hold off
title('Moving Average Filter (Pitch Signal) - No Hand Movement')
xlabel('Sample #')
ylabel('Degree (�)')
legend('No Filter','Moving Average Filter')
grid on

subplot(2,2,2)
plot(ts,slow_pitch,'k')
hold on
plot(ts,slow_pit_mvgAvg,'r','LineWidth',0.7)
hold off
title('Moving Average Filter (Pitch Signal) - Slow Hand Movement')
xlabel('Sample #')
ylabel('Degree (�)')
legend('No Filter','Moving Average Filter')
grid on

subplot(2,2,3)
plot(tf,fast_pitch,'k')
hold on
plot(tf,fast_pit_mvgAvg,'r','LineWidth',0.7)
hold off
title('Moving Average Filter (Pitch Signal) - Fast Hand Movement')
xlabel('Sample #')
ylabel('Degree (�)')
legend('No Filter','Moving Average Filter')
grid on

subplot(2,2,4)
plot(tc,chaotic_pitch,'k')
hold on
plot(tc,chaotic_pit_mvgAvg,'r','LineWidth',0.7)
hold off
title('Moving Average Filter (Pitch Signal) - Chaotic Hand Movement')
xlabel('Sample #')
ylabel('Degree (�)')
legend('No Filter','Moving Average Filter')
grid on
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(3)

subplot(2,2,1)
plot(tn,no_pitch,'k')
hold on
plot(tn,no_pit_mvgAvg,'r')
plot(tn,no_pit_EWMA,'b','LineWidth',0.8)
hold off
title('EWMA Filter (Pitch Signal) - No Hand Movement')
xlabel('Sample #')
ylabel('Degree (�)')
legend('No Filter','Moving Average Filter',string(compose('EWMA Filter (alpha = %0.3f)', a)))
grid on

subplot(2,2,2)
plot(ts,slow_pitch,'k')
hold on
plot(ts,slow_pit_mvgAvg,'r')
plot(ts,slow_pit_EWMA,'b','LineWidth',0.8)
hold off
title('EWMA Filter (Pitch Signal) - Slow Hand Movement')
xlabel('Sample #')
ylabel('Degree (�)')
legend('No Filter','Moving Average Filter',string(compose('EWMA Filter (alpha = %0.3f)', a)))
grid on

subplot(2,2,3)
plot(tf,fast_pitch,'k')
hold on
plot(tf,fast_pit_mvgAvg,'r')
plot(tf,fast_pit_EWMA,'b','LineWidth',0.8)
hold off
title('EWMA Filter (Pitch Signal) - Fast Hand Movement')
xlabel('Sample #')
ylabel('Degree (�)')
legend('No Filter','Moving Average Filter',string(compose('EWMA Filter (alpha = %0.3f)', a)))
grid on

subplot(2,2,4)
plot(tc,chaotic_pitch,'k')
hold on
plot(tc,chaotic_pit_mvgAvg,'r')
plot(tc,chaotic_pit_EWMA,'b','LineWidth',0.8)
hold off
title('EWMA Filter (Pitch Signal) - Chaotic Hand Movement')
xlabel('Sample #')
ylabel('Degree (�)')
legend('No Filter','Moving Average Filter',string(compose('EWMA Filter (alpha = %0.3f)', a)))
grid on
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(4)

plot(tc,chaotic_pitch,'color','#ababab')
hold on
plot(tc,chaotic_pit_mvgAvg,'k','LineWidth',1)
colors = {'#00f','#990091','#f00','#f90','#09b300'};
colors = flip(colors);
labels = {'','','','','',''};
labels{1} = 'Raw Chaotic Pitch Signal';
labels{2} = 'Moving Average Filter';
alphas = [0.05,0.04,0.03,0.02,0.015];
for i=1:5
    aa = alphas(i);
    chaotic_dummy = EWMA(chaotic_pitch,windowSize,aa);
    plot(tc,chaotic_dummy,'color',colors{6-i},'LineWidth',0.7)
    labels{i+2} = string(compose('EWMA (alpha = %0.3f)',aa));
end
title('EWMA Filter - Choosing The Right ''Alpha''')
xlabel('Sample #')
ylabel('Degree (�)')
legend(labels)
grid on
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(5)

subplot(2,2,1)
plot(tn,no_pitch,'k')
hold on
plot(tn,no_pit_TV,'r','LineWidth',0.7)
hold off
title('Total Variation Filter (Pitch Signal) - No Hand Movement')
xlabel('Sample #')
ylabel('Degree (�)')
legend('No Filter','Total Variation Filter (lambda = 12.5)')
grid on

subplot(2,2,2)
plot(ts,slow_pitch,'k')
hold on
plot(ts,slow_pit_TV,'r','LineWidth',0.7)
hold off
title('Total Variation Filter (Pitch Signal) - Slow Hand Movement')
xlabel('Sample #')
ylabel('Degree (�)')
legend('No Filter','Total Variation Filter (lambda = 12.5)')
grid on

subplot(2,2,3)
plot(tf,fast_pitch,'k')
hold on
plot(tf,fast_pit_TV,'r','LineWidth',0.7)
hold off
title('Total Variation Filter (Pitch Signal) - Fast Hand Movement')
xlabel('Sample #')
ylabel('Degree (�)')
legend('No Filter','Total Variation Filter (lambda = 12.5)')
grid on

subplot(2,2,4)
plot(tc,chaotic_pitch,'k')
hold on
plot(tc,chaotic_pit_TV,'r','LineWidth',0.7)
hold off
title('Total Variation Filter (Pitch Signal) - Chaotic Hand Movement')
xlabel('Sample #')
ylabel('Degree (�)')
legend('No Filter','Total Variation Filter (lambda = 12.5)')
grid on
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(6)

subplot(2,1,1)
plot(tn,no_pitch,'k')
hold on
plot(tn,no_pit_EWMA,'r','LineWidth',0.8)
plot(tn,no_pit_hybrid,'b','LineWidth',0.8)
hold off
title('Hybrid vs. EWMA Filter (Pitch Signal) - No Hand Movement')
xlabel('Sample #')
ylabel('Degree (�)')
legend('No Filter',string(compose('EWMA Filter (alpha = %0.3f)', a)),'Hybrid Filter')
grid on

subplot(2,1,2)
plot(tn,no_pitch,'k')
hold on
plot(tn,no_pit_TV,'r','LineWidth',0.8)
plot(tn,no_pit_hybrid,'b','LineWidth',0.8)
hold off
title('Hybrid vs. Total Variation Filter (Pitch Signal) - No Hand Movement')
xlabel('Sample #')
ylabel('Degree (�)')
legend('No Filter','Total Variation Filter (lambda = 12.5)','Hybrid Filter')
grid on
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(7)

subplot(2,1,1)
plot(ts,slow_pitch,'k')
hold on
plot(ts,slow_pit_EWMA,'r','LineWidth',0.8)
plot(ts,slow_pit_hybrid,'b','LineWidth',0.8)
hold off
title('Hybrid vs. EWMA Filter (Pitch Signal) - Slow Hand Movement')
xlabel('Sample #')
ylabel('Degree (�)')
legend('No Filter',string(compose('EWMA Filter (alpha = %0.3f)', a)),'Hybrid Filter')
grid on

subplot(2,1,2)
plot(ts,slow_pitch,'k')
hold on
plot(ts,slow_pit_TV,'r','LineWidth',0.8)
plot(ts,slow_pit_hybrid,'b','LineWidth',0.8)
hold off
title('Hybrid vs. Total Variation Filter (Pitch Signal) - Slow Hand Movement')
xlabel('Sample #')
ylabel('Degree (�)')
legend('No Filter','Total Variation Filter (lambda = 12.5)','Hybrid Filter')
grid on
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(8)

subplot(2,1,1)
plot(tf,fast_pitch,'k')
hold on
plot(tf,fast_pit_EWMA,'r','LineWidth',0.8)
plot(tf,fast_pit_hybrid,'b','LineWidth',0.8)
hold off
title('Hybrid vs. EWMA Filter (Pitch Signal) - Fast Hand Movement')
xlabel('Sample #')
ylabel('Degree (�)')
legend('No Filter',string(compose('EWMA Filter (alpha = %0.3f)', a)),'Hybrid Filter')
grid on

subplot(2,1,2)
plot(tf,fast_pitch,'k')
hold on
plot(tf,fast_pit_TV,'r','LineWidth',0.8)
plot(tf,fast_pit_hybrid,'b','LineWidth',0.8)
hold off
title('Hybrid vs. Total Variation Filter (Pitch Signal) - Fast Hand Movement')
xlabel('Sample #')
ylabel('Degree (�)')
legend('No Filter','Total Variation Filter (lambda = 12.5)','Hybrid Filter')
grid on
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(9)

subplot(2,1,1)
plot(tc,chaotic_pitch,'k')
hold on
plot(tc,chaotic_pit_EWMA,'r','LineWidth',0.8)
plot(tc,chaotic_pit_hybrid,'b','LineWidth',0.8)
hold off
title('Hybrid vs. EWMA Filter (Pitch Signal) - Chaotic Hand Movement')
xlabel('Sample #')
ylabel('Degree (�)')
legend('No Filter',string(compose('EWMA Filter (alpha = %0.3f)', a)),'Hybrid Filter')
grid on

subplot(2,1,2)
plot(tc,chaotic_pitch,'k')
hold on
plot(tc,chaotic_pit_TV,'r','LineWidth',0.8)
plot(tc,chaotic_pit_hybrid,'b','LineWidth',0.8)
hold off
title('Hybrid vs. Total Variation Filter (Pitch Signal) - Chaotic Hand Movement')
xlabel('Sample #')
ylabel('Degree (�)')
legend('No Filter','Total Variation Filter (lambda = 12.5)','Hybrid Filter')
grid on
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(10)

subplot(2,2,1)
plot(tn,no_pitch,'k')
hold on
plot(tn,no_pit_TV,'b')
plot(tn,no_pit_EWMA,'r')
plot(tn,no_pit_hybrid,'g','LineWidth',0.8)
hold off
title('Hybrid Filter (Pitch Signal) - No Hand Movement')
xlabel('Sample #')
ylabel('Degree (�)')
legend('No Filter','Total Variation Filter (lambda = 12.5)',string(compose('EWMA Filter (alpha = %0.3f)', a)),'Hybrid Filter')
grid on

subplot(2,2,2)
plot(ts,slow_pitch,'k')
hold on
plot(ts,slow_pit_TV,'b')
plot(ts,slow_pit_EWMA,'r')
plot(ts,slow_pit_hybrid,'g','LineWidth',0.8)
hold off
title('Hybrid Filter (Pitch Signal) - Slow Hand Movement')
xlabel('Sample #')
ylabel('Degree (�)')
legend('No Filter','Total Variation Filter (lambda = 12.5)',string(compose('EWMA Filter (alpha = %0.3f)', a)),'Hybrid Filter')
grid on

subplot(2,2,3)
plot(tf,fast_pitch,'k')
hold on
plot(tf,fast_pit_TV,'b')
plot(tf,fast_pit_EWMA,'r')
plot(tf,fast_pit_hybrid,'g','LineWidth',0.8)
hold off
title('Hybrid Filter (Pitch Signal) - Fast Hand Movement')
xlabel('Sample #')
ylabel('Degree (�)')
legend('No Filter','Total Variation Filter (lambda = 12.5)',string(compose('EWMA Filter (alpha = %0.3f)', a)),'Hybrid Filter')
grid on

subplot(2,2,4)
plot(tc,chaotic_pitch,'k')
hold on
plot(tc,chaotic_pit_TV,'b')
plot(tc,chaotic_pit_EWMA,'r')
plot(tc,chaotic_pit_hybrid,'g','LineWidth',0.8)
hold off
title('Hybrid Filter (Pitch Signal) - Chaotic Hand Movement')
xlabel('Sample #')
ylabel('Degree (�)')
legend('No Filter','Total Variation Filter (lambda = 12.5)',string(compose('EWMA Filter (alpha = %0.3f)', a)),'Hybrid Filter')
grid on
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function y = mvgAvg(x,W)
    y = zeros(1,length(x));
    for i=1:length(x)
        dummy = zeros(1,W);
        for j=1:W
            if((i-j)<=0)
                dummy(j) = 0;
            else
                dummy(j) = x(i-j);
            end
        end
        y(i) = sum(dummy)/W;
    end
end

function y = EWMA(x,W,alpha)
    y = zeros(1,length(x));
    sLast = 0;
        for i=1:length(x)
            s=0;
            dummy = zeros(1,W);
            for j=1:W
                t = i-j;
                if(t<=0)
                    dummy(j) = 0;
                else
                    dummy(j) = x(t);
                end
            end
            for k=1:W
                s = s + alpha*(1-alpha)^(k-1)*dummy(k);
            end
            s = s + (1-alpha)^(k)*sLast;
            sLast = s;
            y(i) = s;
        end
end

function [y, cost] = tvd_mm(x, lam, Nit)
% [y, cost] = tvd_mm(x, lam, Nit)
% Total variation denoising using majorization-minimization
% and banded linear systems.
%
% INPUT
%   x - noisy signal
%   lam - regularization parameter
%   Nit - number of iterations
%
% OUTPUT
%   y - denoised signal
%   cost - cost function history
%
% Reference
% 'On total-variation denoising: A new majorization-minimization
% algorithm and an experimental comparison with wavalet denoising.'
% M. Figueiredo, J. Bioucas-Dias, J. P. Oliveira, and R. D. Nowak.
% Proc. IEEE Int. Conf. Image Processing, 2006.

% Ivan Selesnick, selesi@nyu.edu, 2011
% Revised 2017

    x = x(:);                                              % Make column vector
    cost = zeros(1, Nit);                                  % Cost function history
    N = length(x);

    I = speye(N);
    D = I(2:N, :) - I(1:N-1, :);
    DDT = D * D';

    y = x;                                                 % Initialization
    Dx = D*x;
    Dy = D*y;

    for k = 1:Nit
        F = sparse(1:N-1, 1:N-1, abs(Dy)/lam) + DDT;       % F : Sparse banded matrix
        y = x - D'*(F\Dx);                                 % Solve banded linear system
        Dy = D*y;
        cost(k) = 0.5*sum(abs(y-x).^2) + lam*sum(abs(Dy)); % cost function value
    end
end